# Robot pick logic

How the robot asks the vision pipeline which box to pick, what it gets back, and what to do with it.

The vision side never moves the robot. It looks at the boxes and answers one question: **which box next, where is the centre of the face to grip, and from which side (front or top)**. Everything after that (path, grip, place) is the robot's.

Background: [architecture.md](architecture.md) (how the pipeline works), [picking_rules.md](picking_rules.md) (the rules in full), [notes/](notes/README.md) (the ideas, for newcomers).

## The cycle

```mermaid
sequenceDiagram
    participant R as Robot
    participant V as Vision (PickDetector)
    R->>R: drive / move to the viewing pose, then stop
    R->>R: make sure the arm and gripper are out of the camera's view
    R->>V: 3-5 frames (colour + depth) of the still scene
    V->>V: run each frame, keep the target most frames agree on
    V-->>R: centroid (x, y, z), approach (front / top), face size
    R->>R: convert to robot coordinates, pick the box
    R->>R: back to the viewing pose: next cycle
```

1. **Stop.** Frames must come from a camera that isn't moving.
2. **Clear the view.** The gripper or a box in the gripper is seen as part of the scene (a box held in the air is still a box, and can become the target).
3. **Take 3–5 frames** and pass them all in one call.
4. **Check the answer** (next section), then pick.
5. **After every pick, look again.** Picking one box can move others. Never reuse an old answer.

## The call

```python
from pick_frame import PickDetector
from faces import up_from_accel, up_from_pitch

detector = PickDetector()          # once at start-up: loads SAM 3.1 (~5 s, ~4.3 GB GPU memory)
UP = up_from_accel(cam.accel)      # the camera's tilt from its motion sensor (USB, or ROS with enable_accel:=true), or up_from_pitch(degrees down)

result = detector.detect_frames([(color, depth_m), ...], intr, UP)
```

| Input | What it is |
|---|---|
| `color` | colour image, BGR, `uint8`, H × W × 3 (1280 × 720 on the D455) |
| `depth_m` | depth in metres, `float32`, H × W, **aligned to the colour image** (0 = no reading) |
| `intr` | the colour camera's intrinsics (`faces.Intrinsics(fx, fy, cx, cy)`) |
| `UP` | which way is up, in camera coordinates. The camera is fixed and doesn't tilt, so this never changes |

`rgbd.Camera` in [`src/rgbd.py`](../src/rgbd.py) gives aligned frames and intrinsics straight from the D455, if the vision PC owns the camera. Frames from elsewhere (ROS topic, files) work too: `detect_frames` only needs the arrays. For a robot program in another Python or language, use `src/pick_loop.py` ([INTEGRATION.md](../INTEGRATION.md)).

**Time:** about 0.3–1 s per frame, more with more boxes in view (SAM 3.1 about 0.25–0.5 s, depth 0.05–0.7 s). 5 frames ≈ 2–5 s.

## The answer

```json
{"x_m": -0.0605, "y_m": 0.2008, "z_m": 0.563, "approach": "top",
 "u": 574.6, "v": 599.1, "size_mm": [169, 102], "num_boxes": 1,
 "frames": 5, "agreeing": 5}
```

| Field | Meaning |
|---|---|
| `x_m`, `y_m`, `z_m` | **where to grip**: the centre of the chosen face, in metres, in **camera coordinates**: x right, y down, z forward (away from the lens) |
| `approach` | `"front"`: come at the face horizontally, towards the camera's side of the box. `"top"`: come down from above |
| `size_mm` | the face's long × short edge, mm |
| `u`, `v` | the same centre in image pixels (for drawing and checking) |
| `num_boxes` | boxes seen |
| `frames`, `agreeing` | frames given, and how many of them found this same target. The answer is the **median** of those that agree; for a top, the frame that saw the most of the top |

`null`: no pickable box in any frame.

### What to do with it

| Answer | Robot does |
|---|---|
| `null` | no box to pick: the carton is empty, or nothing reachable. Check the view, or report done |
| `agreeing` < half of `frames` | the frames disagree (something moved, or a hard scene): take new frames |
| otherwise | convert `x, y, z` to robot coordinates with the camera's pose at the moment of the frames (hand-eye calibration), then pick from the `approach` side |

## Pick, check, next

While the robot picks, the camera watches (the **pick check**, by the Pick Check team: [`pick_watch.py`](../src/pick_watch.py)), with no second run of SAM and no message from the robot. Every camera frame, the depth on the target's pick face is compared with the face's plane: something in front of it (the arm), the face still there, or the face gone (the camera sees past it). Once the box has left its spot, the whole view is compared with the depth from before the pick, until it settles:

| Check says | When | Next |
|---|---|---|
| `picked` | the box left its spot and nothing new stays in view: the arm has carried it out of the picture (about 1 s after it leaves; at most 10 s if the arm stays in view) | the next box |
| `dropped` | the box left its spot, then a new surface stands still in the carton, not touching the picture's edge: the box fell back in (anywhere, also onto its own spot) | pick again (a retry); the box is looked for where it fell |
| `missed` | the arm came and went, the box is still on its spot | pick again: usually the same box (a retry) |
| `moved` | the arm came and went, the box is neither there nor gone: knocked or dragged | pick again |

After 2 retries on the same box a **flag** is raised for a person, once, with photos of the box (the scene with it marked, a close-up, the last check). The box is **not skipped**: it is tried again (try 4, 5, …) as long as the picker chooses it.

The camera only says which box and whether the pick worked; the robot never has to report. All of this runs in one program, [`pick_loop.py`](../src/pick_loop.py), which owns the camera and must get every camera frame (30 a second over USB). The robot base must not move between the target and the result.

## How the target is chosen

The robot always gets **one** box. The rules, in order:

1. **Only front or top faces.** A face pointing at the camera is picked from the front, a face pointing up from above. A side face (left/right) is never picked.
2. **Which face** ([`pick_rules.py`](../src/pick_rules.py)). A box **on another box**: its **front**. A box **on the base** (no box under it): the larger of its front and top, in real size. A top counts only if it is as wide as the front (else it's a sliver of another box), and if its front edge is seen at 10° or more (else it's almost edge-on and measured badly); otherwise the front is used. A box on a box with only its top found is picked by its top as a last resort, with a `flag` event (reason `top face only`) and `"top_only": true` in the target; the robot still picks it. **Top faces mode** (`--top-faces`, or F in the window's Advanced tab): the larger face for every box, as before 5 Nov 2026.
3. **Nothing on top of it.** A box with another box resting on it waits: the one on top goes first.
4. **Nothing in front of it.** A box with another box in its way, or with a nearer box hiding part of it, waits: the box in front goes first. A box lying on top of a stack is *not* blocked by the stack below it. When the camera can't see whether a box stands **on** a nearer box or **behind** it (a level camera sees tops edge-on), it counts as *on*: nothing is pulled out from under a box, but the robot may have to reach over a box. Details: [picking_rules.md](picking_rules.md).
5. **The highest top first.** Of the free boxes, on a box or on the floor, the ones whose top is within 1.5 cm of the highest. Stacks are cleared from the top down, even when a stack's top stands a few cm further back, and a tall box standing on the floor goes before a lower stack.
6. **Nearest, then leftmost.** Of those, the ones whose grip point is within 3 cm of the nearest one, then the leftmost.

![How the next box is chosen](images/pick_logic_flow.png)

So a stack is cleared from the top down, the front boxes go before the ones behind, and nothing is pulled from under another box, or from beside the boxes holding up a stack, while that stack stands.

## Coordinates

```
            z (forward, away from the lens)
           /
          /
 camera  o-------- x (right)
         |
         |
         y (down)
```

- Metres, from the colour camera's optical centre.
- The robot needs the **camera's pose on the robot** (hand-eye calibration) to turn this into its own frame. Because the robot stops before each look, the pose at capture time is the pose at answer time.

## Assumptions the robot side must keep

| Assumption | Why it matters | If it's broken |
|---|---|---|
| The camera is fixed and doesn't tilt | "up" is set once; it decides front vs top, levels tops, and finds boxes resting on others | wrong `approach`, wrong tops; pass the new `UP` |
| `UP` matches the real mounting | as above | read the camera's accelerometer before each pick (USB: needs the librealsense udev rules; ROS: driver with `enable_accel:=true`), or set `up_from_pitch(<degrees down>)` |
| The robot is still while the frames are taken | the answer combines the frames | `agreeing` drops; results smear |
| Arm and gripper out of view | anything box-like is a box | a held box can become the target |
| Depth aligned to colour | every pixel's depth must match its colour pixel | sizes and centres are wrong |
| Boxes about 0.35–0.6 m from the camera (what has been tested) | depth noise grows with distance | at 0.5 m the centre moves ~1 mm frame to frame; further away, more. Test before using other distances |

## What it can get wrong (check on the robot)

- **Two boxes pressed together** (side by side, or one lying on the other) with their fronts level are drawn as one outline by the AI. When the doubled face is about twice as thick as other boxes of the same length in view (at least 3 of them), it is split in two and the left or top one is picked. Alone, or among boxes of other sizes, it can't be told: check `size_mm` against the boxes you expect. If a box really is twice as thick as its neighbours of the same length, it is split by mistake; the grip point then lands a quarter of the way across that box, still on it.
- **Anything box-shaped counts**, including things outside the carton (a case on the table). Keep the view to the carton, or tell us to limit the search to it.
- **A top seen at a flat angle** (camera nearly level with it) is measured less well: 1° of error in `UP` moves its front-to-back size 5–6 mm. With the camera's real tilt, 170 × 100 tops measured 167–170 × 96–101.

## Not returned yet

- **Rotation of the face.** The answer gives the centre and the approach side, not how the face is turned (a box standing at an angle). The pipeline measures it (each face's normal and edges); tell us if the gripper needs it, and it can be added to the answer.
- **Which box comes next.** Only the current target; the next one is decided after the next look.
